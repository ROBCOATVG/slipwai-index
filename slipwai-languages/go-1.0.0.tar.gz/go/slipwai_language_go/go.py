"""The Go backend: one module per service, its committed variants, and the workspace above them.

This is the `go` language package: core loads it from the language directory, and its assets are read from
the `assets/` beside this package."""
from __future__ import annotations

from pathlib import Path

from slipwai import registry as protocol
from slipwai.assets import asset_tree
from slipwai.backends import APP
from slipwai.errors import GenerationError
from slipwai.images import REPOSITORY
from slipwai.project.backing_services import backing_service_service_files
from slipwai.project.ci_workflows import dependency_paths
from slipwai.project.composition import wire_store
from slipwai.project.flag_route import wire_entry
from slipwai.project.flags import flag_reader
from slipwai.selection import Selection
from slipwai.services import App
from slipwai.tooling import package_name

from . import go_layout as layout
from . import go_project as project
from . import go_toolchain as toolchain
from .go_project import GO_GREMLINS, GO_MUTATION_SCRIPT
from .go_prune_rows import PRUNE_ROWS
from .go_toolchain import GO_COVDATA_READY, GO_COVERAGE_MINIMUM, GO_COVERAGE_SCRIPT, GO_STATICCHECK, GO_TEST_COMMAND

# This package's own assets, the layout core's readers use for every language: `languages/go/…` and
# `backing-services/go/…` beneath it. Resolved from this file, so a checkout and a copy in the home directory
# read the same files.
ASSETS = Path(__file__).resolve().parents[1] / "assets"
# The token the mutation script carries where the pinned Gremlins release goes, so the pin is written once.
GO_GREMLINS_TOKEN = "__GO_GREMLINS__"
# What this service calls itself in a trace, carried in `config.go` as a token for the reason the module
# path is: the file is Go, and an exported span has to name the service rather than the template it came
# from. Resolved in `name_service`, where the project's name is known.
SERVICE_NAME = "__SERVICE_NAME__"


def service_files(event: bool, selection: Selection, target: str = "none") -> dict[str, str]:
    """What this backend puts in a service's directory, keyed relative to it."""
    files = asset_tree(ASSETS / "languages/go/app")
    files["go.mod"] = go_module(selection)
    checksums = go_checksums(selection)
    if checksums is not None:
        files["go.sum"] = checksums
    if event and not selection.has("memory"):
        # Only for a backend whose event-store axis is not offered yet: a port with a shape and no
        # adapter behind it. Once the axis is asked, the port and its adapters arrive together.
        files.update(asset_tree(ASSETS / "languages/go/event-port"))
    files.update(backing_service_service_files(selection, "go"))
    # The flag reader, only where there is somewhere to deploy: a flag is what makes a merge and a release
    # two decisions, and `--target none` has neither the mechanism nor the unsafe push. See `flags.py`.
    files.update(flag_reader(target, "go"))
    # And the entry point's half of it: the source is handed to `BuildApp`, which is what puts
    # `/api/flags` in front of the browser app. `nil`, not an unresolved placeholder, with no reader.
    wire_entry(files, target, "go")
    # And the store's half: which adapter this project opens, and what `/ready` is handed. See
    # `composition.py` — the entry point is the only place that may name the answer.
    wire_store(files, selection, "go")
    return files


# The only features that add a Go module requirement, and therefore the only ones that change go.mod and
# go.sum. Read combinatorially below, the way TypeScript's `LOCK_FEATURES` is, so one dependency set has
# exactly one name.
MODULE_FEATURES = ("postgres", "sqlite")


def go_module_variant(selection: Selection) -> str:
    """Which committed module files match this selection's dependency set.

    Go has no SQL driver in its standard library, so a real event store means a module
    requirement — and a requirement means a `go.sum`, which only `go mod tidy` can write. The two
    are committed per variant for the same reason the npm lockfiles are: a manifest and its
    checksums have to move together, and `go build` refuses a go.sum that disagrees with go.mod.

    Combinatorial rather than a priority chain, which is what this was: a chain returns the first
    feature it matches and silently ignores the rest, so it was correct only while no two
    dependency-adding options could be selected together — `net-http` and `keycloak` add no packages.
    The day one axis's answer adds a requirement beside another's, a chain names a variant that is
    missing half the dependency set and `go build` fails somewhere unrelated. Joined in the order
    above, so one set has exactly one name, and `base` for a selection that requires nothing at all.
    """
    chosen = [feature for feature in MODULE_FEATURES if selection.has(feature)]
    return "-".join(chosen) or "base"


def go_module(selection: Selection) -> str:
    return (ASSETS / f"languages/go/modules/{go_module_variant(selection)}/go.mod").read_text()


def go_checksums(selection: Selection) -> str | None:
    """The committed `go.sum`, or None for a variant that requires nothing."""
    path = ASSETS / f"languages/go/modules/{go_module_variant(selection)}/go.sum"
    return path.read_text() if path.is_file() else None


def go_language_version(module: str) -> str:
    """The `go` directive of a module file, so go.work cannot pin an older language than go.mod.

    A dependency may require a newer language version than the base module asks for, and
    `go mod tidy` raises the directive when it does. A workspace pinned lower than its only module
    is a workspace that refuses to build.
    """
    for line in module.splitlines():
        if line.startswith("go "):
            return line.split(None, 1)[1].strip()
    raise GenerationError("the committed go.mod has no `go` directive")

def name_service(project_name: str, service: App, files: dict[str, str]) -> dict[str, str]:
    """One service's files under this project's own module path: `example.com/<project>/<service>`."""
    # Every import of the service's own packages names the module path, so renaming the module
    # in go.mod alone would leave a project that does not compile.
    module = f"example.com/{project_name}/{service.name}"
    for path in list(files):
        if path.startswith(f"{service.path}/") and path.endswith((".go", "go.mod")):
            content = files[path].replace("example.com/delivery-starter", module)
            # What this service calls itself in a trace, for the same reason the module path is
            # rewritten: a name the exporter carries has to be the project's and not the template's.
            files[path] = content.replace(SERVICE_NAME, package_name(project_name, service))
    return files


def repository_files(
    project_name: str, files: dict[str, str], services: list[App], verify: str
) -> dict[str, str]:
    """The workspace above the services, the two gate scripts, and the verify script.

    One module per service and one `go.work` naming them all, which is what Go itself asks of a repository
    with more than one module: each service keeps its own `go.mod` and `go.sum` — the committed variants —
    so a second service is a second `use` line and not a second dependency set to lock. A shared module
    under `packages/` is one more `use` line, and every service imports it by path with no `replace`.

    The gate scripts are written once for the family, however many Go services there are: `make test`'s
    coverage gate and `make mutation`'s Gremlins wrapper, which stages a service beside the workspace modules
    it imports because Gremlins copies only the module it mutates (`go_project.py` has the account).
    The wrapper carries the pinned release, substituted here so the pin is written in one place. The verify
    script names the coverage gate beside itself rather than from the root, because a delivery layout moves
    `scripts/` and re-points every root-relative path but the ones inside code (`layout.py`).
    """
    uses = "".join(f"use ./{service.path}\n" for service in services)
    files["go.work"] = f"go {go_language_version(files[f'{services[0].path}/go.mod'])}\n\n{uses}"
    for script in (GO_COVERAGE_SCRIPT, GO_MUTATION_SCRIPT):
        files[script] = (ASSETS / f"languages/go/{script}").read_text().replace(GO_GREMLINS_TOKEN, GO_GREMLINS)
    apps = " ".join(service.path for service in services)
    files[verify] = f"""#!/bin/sh
set -eu
{GO_COVDATA_READY}
for app in {apps}; do
  test -z "$(gofmt -l "$app")"
  (cd "$app" && go vet ./... && {GO_STATICCHECK} && {GO_TEST_COMMAND})
  python3 "$(dirname "$0")/{GO_COVERAGE_SCRIPT.split('/')[-1]}" "$app" {GO_COVERAGE_MINIMUM}
done
"""
    return files


def ci_toolchain_setup(services: list[App]) -> str:
    """One Go version for the workspace, read from the first Go service's module; `go.work` pins the rest.

    The cache is keyed on every module's `go.sum` and the workspace's `go.work.sum` by name, because
    setup-go's default key is a `go.sum` at the root, which a workspace does not have: it restores nothing,
    saves nothing, says so only as a warning, and the run stays green and downloads and compiles every module
    from cold each time — a cache that never hits looks like one that does.
    """
    return (
        "      - uses: actions/setup-go@v7\n        with:\n"
        f"          go-version-file: {services[0].path}/go.mod\n"
        "          cache-dependency-path: "
        + dependency_paths([*(f"{s.path}/go.sum" for s in services), "go.work.sum"])
        + "\n"
    )


LANGUAGE = protocol.Language(
    (protocol.Family("go", toolchain.FAMILY | layout.FAMILY_ANSWERS | project.FAMILY_ANSWERS | {
        protocol.CI_TOOLCHAIN_SETUP: ci_toolchain_setup,
        protocol.PRUNE_ROWS: PRUNE_ROWS,
    }),),
    (protocol.Backend("go", "go", toolchain.BACKEND | {
        protocol.SERVICE_FILES: service_files,
        protocol.NAME_SERVICE: name_service,
        protocol.REPOSITORY_FILES: repository_files,
        protocol.READY_PATH: "/ready",
        protocol.HEALTH_BODY: '{"status":"ok"}',
        protocol.IMAGE_BUILDER: {
            "tool": "ko",
            # `--bare` so the image is exactly `__REPOSITORY__`, `--local` so it lands in the daemon like every
            # other backend's and `make push` is one command for all of them. ko's default base is Chainguard's
            # static image, which is right for a binary that needs nothing; `KO_DEFAULTBASEIMAGE` overrides it.
            "build": (
                f"cd {APP} && KO_DOCKER_REPO={REPOSITORY} ko build ./cmd/serve --bare --local "
                "--tags $(GIT_SHA) --platform $(PLATFORM)"
            ),
        },
        # A second image, because ko builds one binary per image: the one-off task runs `cmd/migrate`.
        protocol.MIGRATIONS_IN_PRODUCTION: {"image": "migrate", "build": (
            f"cd {APP} && KO_DOCKER_REPO={REPOSITORY} ko build ./cmd/migrate --bare --local "
            "--tags $(GIT_SHA) --platform $(PLATFORM)"
        )},
        # pgx parses it as libpq does, where `require` is "encrypt, do not verify".
        # Per managed-database kind; `images.py`, above `POSTGRES_SSLMODE_KINDS`, says how each was measured.
        protocol.POSTGRES_SSLMODE: {"rds": "require", "flexible-server": "require"},
        protocol.SERVICE_DESCRIPTORS: {},
        **layout.ANSWERS,
        **project.ANSWERS,
    }),),
)
